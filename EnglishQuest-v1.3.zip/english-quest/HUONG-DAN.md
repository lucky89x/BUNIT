# ENGLISH QUEST – Hành trình giải cứu Vương quốc Ngôn ngữ

Game phiêu lưu nhập vai (RPG 2D) giúp học sinh lớp 6 – lớp 8 học lại tiếng Anh từ mất gốc (Pre-A1 → A1).
Chạy trên máy tính Windows bằng **Google Chrome** hoặc **Microsoft Edge**, **không cần mạng**, **không quảng cáo**, **không mua bán**, **không gửi dữ liệu đi đâu**.

---

## 1. Cách chạy game (không cần biết lập trình)

1. Giải nén file ZIP vào một thư mục, ví dụ `D:\EnglishQuest`.
2. Chọn **một** trong hai cách:
   - **Cách A (đơn giản nhất):** bấm đúp vào `index.html`. Game mở trong Chrome/Edge.
     Nếu máy mở bằng trình duyệt khác: chuột phải `index.html` → *Open with* → chọn Chrome hoặc Edge.
   - **Cách B (ổn định nhất cho việc lưu tiến độ):** bấm đúp vào `Chay-game.bat`.
     Một cửa sổ đen hiện ra và trình duyệt tự mở game tại `http://localhost:8765`. **Giữ cửa sổ đen mở** trong lúc chơi; đóng nó khi chơi xong.
3. Lần sau, mở lại **đúng cách đã dùng lần trước** để thấy tiến độ cũ.

> ⚠️ Cách A và cách B lưu dữ liệu ở hai chỗ khác nhau trong trình duyệt. Nếu muốn chuyển, vào **Phụ huynh → Sao lưu (tải file JSON)** rồi mở cách kia và chọn **Khôi phục từ file JSON**.

Nếu game báo *"Trình duyệt đang chặn lưu dữ liệu"*, hãy dùng **Cách B**.

## 2. Điều khiển

| Phím | Chức năng |
|---|---|
| **W A S D** hoặc **phím mũi tên** | Di chuyển |
| **E** hoặc **Space** | Nói chuyện, nhặt đồ, mở rương, mở cổng |
| **Chuột** | Chọn đáp án, bấm 🔊 để nghe, mở menu |
| **1 – 4** | Chọn nhanh đáp án |
| **I / N / Q / M** | Túi đồ / Sổ từ vựng / Nhiệm vụ / Bản đồ |
| **Esc** | Tạm dừng, đóng cửa sổ |

Trên màn hình: người có dấu **❗** đang cần giúp; dấu **…** là đang chờ bạn quay lại; **mũi tên vàng** chỉ đường tới nhiệm vụ.

## 3. Nghe phát âm tiếng Anh

Game dùng giọng đọc có sẵn của trình duyệt. Microsoft Edge thường có sẵn giọng tiếng Anh rất tự nhiên.
Nếu bấm 🔊 mà không nghe thấy:

1. Mở **Settings (Cài đặt) → Time & Language (Thời gian & Ngôn ngữ) → Speech (Giọng nói)**.
2. Mục *Manage voices / Quản lý giọng nói* → **Add voices** → chọn **English (United States)** và/hoặc **English (United Kingdom)**.
3. Khởi động lại trình duyệt.

Trong **Cài đặt** của game có thể chọn giọng **Anh – Mỹ / Anh – Anh**, chọn giọng cụ thể và **chỉnh tốc độ đọc**. Nút 🐢 đọc chậm.
Nếu máy chưa có giọng đọc, game vẫn chơi bình thường (câu hỏi "nghe" sẽ tự đổi thành "đọc và chọn hình").
Game **không** dùng micro và **không** chấm điểm phát âm.

## 4. Nội dung phiên bản 1.0

- **3 vùng đất khám phá được:** Làng Khởi Đầu → Rừng Từ Vựng → Lâu Đài Ngữ Pháp (+ cổng tới Hải Cảng Nghe Hiểu cho phiên bản sau).
- **19 nhiệm vụ chính + 3 thử thách nâng cao** (mở khi bé tiến bộ tốt), **3 trận đánh trùm**.
- **140 từ vựng** có nghĩa tiếng Việt, câu ví dụ, nút nghe; **12 bài ngữ pháp** (chào hỏi, a/an, am/is/are, số nhiều, he/she, have/has, trật tự câu, hiện tại đơn, do/does, don't/doesn't, giới từ, can/can't); **75 câu điền từ**, **28 câu sắp xếp**.
- **6 dạng thử thách gắn với hành động:**
  1. Truy tìm đồ vật (tìm 3 quả táo **đỏ**, tìm con mèo **đen**, tìm chuối và cá)
  2. Mở cánh cổng bí mật (điền am/is/are, have/has, can/can't)
  3. Chiến đấu với quái vật dễ thương (trả lời đúng = tung phép thuật)
  4. Hội thoại với NPC (chọn hoặc tự ghép câu trả lời)
  5. Rương kho báu (nghe từ và chọn hình đúng)
  6. Nhiệm vụ đời sống (đi chợ theo danh sách tiếng Anh, tính tiền)
- Ngoài ra: sắp xếp câu, ghép chữ, câu hỏi giới từ có tranh minh họa, đoán hoạt động.
- XP, cấp độ, vàng (chỉ trong game), túi đồ, 8 bộ trang phục, 16 huy hiệu, bản đồ khám phá, vùng bí mật.

## 5. Học tập được thiết kế thế nào

- **Dạy trước – làm sau:** mỗi nhiệm vụ mở ra bằng thẻ từ mới / bài ngữ pháp ngắn bằng tiếng Việt, có ví dụ và nút nghe, sau đó mới yêu cầu thực hành.
- **Sai không bị phạt nặng:** tinh linh Pip giải thích bằng tiếng Việt và cho thử lại. Trong trận đấu, hết tim thì được hồi đầy để thử tiếp.
- **Ôn tập ngắt quãng (Leitner 6 hộp):** từ trả lời sai sẽ được hỏi lại sớm (10 phút), từ nhớ tốt hỏi lại sau 1 – 3 – 7 – 16 ngày. Từ đến hạn ôn tự xuất hiện trong trận đấu và khi trò chuyện với dân làng. Sổ từ vựng có nút **Ôn tập nhanh**.
- **Tự điều chỉnh độ khó:** dựa trên tỷ lệ đúng và số lần dùng gợi ý gần đây: số đáp án (3 → 4), có/không hiện sẵn nghĩa tiếng Việt, thêm dạng nghe, ghép chữ, tự ghép câu trả lời khi hội thoại.
- **Bài khởi động 10 câu** (có thể bỏ qua) để chọn mức xuất phát. Không mặc định lớp 8 giỏi hơn lớp 6.
- **Không gây nghiện:** không có thời gian đếm ngược, không phần thưởng đăng nhập hằng ngày, có **nhắc nghỉ sau 20 phút** (phụ huynh chỉnh được). Gợi ý nhẹ nhàng khi học hơn 30 từ mới/ngày.

## 5b. Bản 1.1 – Chống đoán mò (bắt buộc phải hiểu mới qua)

- **Cổng phép thuật, bài kiểm tra của NPC, rương kho báu, thử thách hôm nay:** chỉ tính câu **đúng ngay lần đầu**. Chọn sai → Pip giải thích, rồi hỏi lại **bằng một câu khác cùng kiến thức** (đổi câu, đổi dạng, xáo đáp án). Sai 2 lần cùng một kiến thức thì được làm lại có hướng dẫn để không bị kẹt.
- **Không loại trừ dần đáp án:** chọn sai không làm đáp án đó biến mất; mọi lựa chọn được xáo lại, nên bấm bừa lần lượt không qua được.
- **Dạng mới – Gõ từ:** nhìn hình + nghĩa tiếng Việt, tự gõ từ tiếng Anh (gợi ý hiện dần từng chữ cái).
- **Dạng mới – Câu đố đọc hiểu:** chỉ có tiếng Anh (ví dụ *"You open the door with it."*), phải hiểu mới chọn đúng hình. Có 55 câu đố.
- **Trùm đòi thuộc từ:** muốn đấu Vua Slime / Vua Nấm / Người Đá, bé phải thuộc **ít nhất 50% từ của vùng** (mỗi từ trả lời đúng ngay lần đầu ít nhất 2 lần). Chưa đủ thì Pip báo số từ đã thuộc và mở ngay bài **Luyện từ** 8 từ yếu nhất.
- **Hết tim khi đấu:** trùm/quái vật hồi đầy máu khi đấu lại → không thể thắng bằng cách đoán mãi.
- **⭐ Thử thách hôm nay:** mỗi ngày 1 lần, 8 câu ôn các từ đến hạn + ngữ pháp (Sổ từ vựng → nút ⭐). Huy hiệu "Kiên trì 5 ngày".
- **Bảng phụ huynh** có thêm "Độ thuộc từ theo vùng" và số lần hoàn thành thử thách hôm nay.

## 5c. Bản 1.2 – Học theo sách Global Success, nhớ lâu, luyện nói

**📗 Học theo sách (phím B, nút "Sách", hoặc gặp Cô giáo Hoa trong làng):**
- Chọn sách **Tiếng Anh 6** hoặc **Tiếng Anh 8 – Global Success** và **Unit đang học ở lớp** (Unit đó được đưa lên đầu).
- 24 Unit (12 Unit lớp 6 + 12 Unit lớp 8), **205 từ theo chủ đề** của từng Unit, có nghĩa, câu ví dụ, nút nghe. Mỗi lần học 8 từ, sau đó luyện ngay (phải đúng lần đầu).
- ⚠️ Đây là **từ theo chủ đề do game soạn**, không phải danh sách chính thức in trong sách. Trọng tâm ngữ pháp ghi ở mỗi Unit chỉ để tham khảo, phụ huynh nên đối chiếu với sách.
- **Phụ huynh nhập đúng từ trong sách:** Bảng phụ huynh → "📝 Nhập từ theo sách". Mỗi dòng: `từ = nghĩa` (có thể thêm `| câu ví dụ | nghĩa câu`). Từ nhập vào sẽ xuất hiện trong mục Sách, trận đấu, ôn tập hằng ngày.
- Từ học theo sách cũng được đưa vào trận đấu với quái vật và Thử thách hôm nay → ôn đi ôn lại tự nhiên.

**🧠 Nhớ lâu, tránh nhớ tạm (thay đổi thuật toán ôn tập):**
- Trả lời đúng nhiều lần liên tiếp **trong cùng một buổi không được tính lên mức**. Một từ chỉ lên mức khi bé nhớ lại được **sau khi đã qua một khoảng thời gian** (10 phút → 1 ngày → 3 ngày → 7 ngày → 16 ngày).
- Chọn hình/chọn nghĩa (nhận biết) chỉ đưa từ tới mức "Đang nhớ". Muốn **"Nhớ tốt"** phải **tự nhớ ra từ** (gõ từ, ghép chữ, chọn từ tiếng Anh từ nghĩa tiếng Việt).
- Từ đã nhớ tốt mà trả lời sai sẽ bị hạ mức và được hỏi lại sớm.
- Mục Sách hiển thị 3 mức cho từng Unit: Đã học / Đang nhớ / **Nhớ lâu** (nhớ lại được sau ≥ 1 ngày).

**🎤 Luyện nói (tùy chọn, mặc định TẮT):**
- Bật trong Bảng phụ huynh. Cần Internet, micro và Chrome/Edge. Giọng nói được trình duyệt gửi tới máy chủ nhận dạng của Google/Microsoft.
- Sau khi trả lời đúng trong hội thoại, hoặc ở thẻ từ mới, bé bấm **🎤 Nói thử** và nói lại câu. Game chỉ kiểm tra "máy có nghe ra đúng câu không" và cho thêm chút XP, **không chấm điểm phát âm**.

## 5d. Bản 1.3 – Đồ họa mới, Khu vui chơi, từ vựng đúng theo sách

**🎨 Đồ họa:** nền cỏ/đất/đá có vân và đổ bóng; cây cao nhiều tầng tán (nhân vật đi ra sau cây thì tán cây mờ đi); bờ nước có bọt sóng; đường đất có viền cỏ; nhân vật có viền nổi bật; tia nắng xiên, mây trôi, cánh hoa rơi (Làng), đom đóm (Rừng), bụi sáng (Lâu đài).

**🎮 Khu vui chơi** (nút hồng góc dưới bên trái, hoặc phím G) – 4 trò chơi dùng từ của Unit đang học / từ cần ôn:
- 🏎️ **Đua xe từ vựng**: đánh lái qua cổng có từ tiếng Anh đúng (đúng → tăng tốc).
- 🧺 **Hứng chữ**: di chuyển giỏ hứng chữ cái theo đúng thứ tự để ghép từ (luyện chính tả; mỗi từ có 3 tim).
- 🧗 **Vượt chướng ngại** (kiểu Roblox obby): chạy, nhảy qua các bục; húc vào khối có từ đúng để cây cầu hiện ra.
- 🎈 **Bắn bóng bay**: bấm vào quả bóng có từ đúng, không tính giờ.
Mỗi câu trả lời trong trò chơi được ghi vào hệ thống ôn tập; cuối ván có danh sách từ cần ôn lại. Có kỷ lục điểm riêng cho từng bé.

**📘 Từ vựng đúng theo sách:** đã nhập **712 từ mới** từ ảnh "Sổ tay kiến thức Toán Văn Anh lớp 6 & lớp 8" mà phụ huynh tải lên Google Drive (cùng 134 từ trùng với từ đã có), chia đúng theo 24 Unit. File dữ liệu: `js/data/sgk-words.js` – mỗi dòng `từ = nghĩa`, phụ huynh có thể sửa trực tiếp nếu thấy sai.

## 6. Hai bé chơi riêng

Mỗi bé tạo **một nhân vật riêng** (tên, lớp, tuổi, kiểu tóc, màu tóc, màu da). Tiến độ, từ vựng, độ khó, lỗi sai, huy hiệu của mỗi bé hoàn toàn độc lập. Có thể tạo tối đa 6 hồ sơ.

## 7. Bảng phụ huynh

Từ màn hình chính → **👨‍👩‍👧 Phụ huynh** (giải một phép nhân nhỏ để vào). Xem cho từng bé:
- Tổng thời gian, thời gian hôm nay, biểu đồ 7 ngày
- Nhiệm vụ đã xong, số từ đã gặp, trình độ ước tính
- Tỷ lệ đúng theo chủ đề, chủ điểm ngữ pháp đã học
- Từ nhớ tốt / từ cần ôn, lỗi hay gặp, **gợi ý nên ôn phần nào**
- Cài nhắc nghỉ (tắt / 15 / 20 / 30 / 45 / 60 phút)
- **Sao lưu / khôi phục file JSON**, dùng bản dự phòng tự động, chơi lại từ đầu, xóa hồ sơ

Nên **sao lưu file JSON mỗi tuần** (ví dụ chép vào USB hoặc Google Drive).

## 8. Xử lý sự cố

| Hiện tượng | Cách xử lý |
|---|---|
| Không nghe được tiếng | Xem mục 3; kiểm tra loa; bật "Nhạc nền/Hiệu ứng" trong Cài đặt |
| Mất tiến độ khi mở lại | Mở lại đúng cách đã dùng (index.html hay Chay-game.bat); hoặc Phụ huynh → Khôi phục |
| Báo dữ liệu lỗi | Game tự lấy bản dự phòng; hoặc Phụ huynh → Dùng bản dự phòng tự động / Khôi phục JSON |
| Màn hình quá nhỏ/to | Game tự co giãn theo cửa sổ; bấm F11 để toàn màn hình |
| Chay-game.bat không chạy | Bấm dùng index.html (Cách A) |

## 9. Cấu trúc mã nguồn (để mở rộng)

```
english-quest/
├─ index.html            Trang chính
├─ Chay-game.bat         Chạy qua máy chủ cục bộ (Windows)
├─ tools/server.ps1      Máy chủ cục bộ siêu nhỏ bằng PowerShell
├─ css/style.css         Giao diện
├─ js/data/vocab.js      140 từ vựng (thêm từ: thêm 1 dòng W(...))
├─ js/data/lessons.js    Bài ngữ pháp, câu điền từ, câu sắp xếp, cảnh giới từ
├─ js/data/quests.js     Nhiệm vụ, hội thoại, trùm, vật phẩm, trang phục, huy hiệu
├─ js/data/curriculum.js Từ theo chủ đề 24 Unit Global Success 6 & 8
├─ js/data/maps.js       Bản đồ 3 vùng (vẽ bằng lệnh rect/hline/house...) và vị trí NPC
├─ js/core/              Lưu trữ, âm thanh tự tạo, giọng đọc, hệ thống học (ôn tập ngắt quãng, độ khó)
├─ js/engine/            Đồ họa pixel tự vẽ, thế giới, va chạm, camera, bản đồ nhỏ
├─ js/ui/                Hộp thoại, câu hỏi, trận đấu, các màn hình
├─ js/game.js            Vòng lặp game, nhiệm vụ, phần thưởng
└─ tests/                Kiểm thử dữ liệu và bot tự chơi hết chương 1
```

**Thêm vùng 4 – Hải Cảng Nghe Hiểu:**
1. Trong `maps.js` tạo `EQ.REGIONS.harbor = { name, w, h, spawn, entities, monsters, build() }` giống các vùng khác.
2. Trong `castle` đổi cổng `toHarbor` thành `{ kind:'portal', to:'harbor', tx:1, ty:14, need:'boss:golem' }` và bỏ đoạn "sắp ra mắt" trong `G.usePortal` (game.js).
3. Thêm `'harbor'` vào `REGION_ORDER` trong `game.js`.
4. Thêm từ (`r:'harbor'`), bài học, nhiệm vụ (`region:'harbor'`), trùm vào các file dữ liệu tương ứng.
5. Chạy `node tests/data-check.cjs` để kiểm tra bản đồ đi tới được mọi nơi và dữ liệu không thiếu.

**Kiểm thử (dành cho người lập trình):**
- `node tests/data-check.cjs` – kiểm tra từ vựng, ngữ pháp, nhiệm vụ, bản đồ.
- `node tests/playthrough.cjs` – bot tự chơi hết chương 1 trên Chromium (cần Playwright).
- `node tests/arcade.cjs` – bot tự chơi 4 trò trong Khu vui chơi.
- `node tests/anti-guess.cjs` – kiểm tra chống đoán mò, thuật toán nhớ lâu, học theo sách, so khớp câu nói.

## 10. Bản quyền nội dung

Toàn bộ hình vẽ pixel, bản đồ, nhạc nền và hiệu ứng âm thanh đều **được tạo bằng mã nguồn** trong game (không dùng ảnh/nhạc bên ngoài). Biểu tượng cảm xúc (emoji) hiển thị bằng phông chữ có sẵn của Windows. Giọng đọc là của hệ điều hành/trình duyệt.
